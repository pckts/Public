#Windows-RestoreIPv6

#Relevance trigger, if file is not found, script will not run
$FailsafeExist = Test-Path -Path "C:\Windows-DisableIPv6\RollbackFile_*.csv"
if ($FailsafeExist -ne $true)
{
    exit
}

#Minor shell setup
$ProgressPreference = "SilentlyContinue"
$hostname = hostname

#Require script to be run as admin
$currentPrincipal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if ($currentPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator) -eq $false)
{
  Clear-Host
  write-host "Please run as admin..."
  sleep 1
  break
}

#Create folder structure to be used
$FolderExist = Test-Path -Path C:\Windows-RestoreIPv6
if ($FolderExist -ne $true)
{
    New-Item -ItemType "directory" -Path C:\Windows-RestoreIPv6 | Out-Null
    sleep 1
}

#Gets the current time to be used as timestamp suffix and removes any non-digits from string
$WholeTime = Get-Date -UFormat "%T"
#This regex is overkill but ensures removal of non-digits regardless of formatting used by system
$FormattedTime = $WholeTime -replace "[^\p{N}]+"

$transcriptFile = "C:\Windows-RestoreIPv6\RestoreLog_" + "$FormattedTime" + ".txt"
Start-Transcript -Path $transcriptFile

$ShareHostname = "QZQZQPLACEHOLDERQZQZQ2"
$OutputFileReport = "\\$ShareHostname\Windows-RestoreIPv6_Reports\IPv6Restored_" + "$hostname" + ".csv"

#Create log if first run
$HasReported = Test-Path -Path C:\Windows-RestoreIPv6\hasReported.log
if ($HasReported -ne $true)
{
    New-Item -ItemType "file" -Path C:\Windows-RestoreIPv6\hasReported.log | Out-Null
    sleep 1
}

clear-host
$BackupFiles = "C:\Windows-DisableIPv6\RollbackFile_*.csv"
$OriginalBackupFile = dir $BackupFiles | sort lastwritetime | select -First 1
Copy-Item $OriginalBackupFile -Destination $OutputFileReport
[array]$BackupInterfaces = Import-Csv -Path $OriginalBackupFile 
$InterfacesToEnable = $BackupInterfaces | Where-Object Enabled -eq True
foreach ($InterfaceToEnable in $InterfacesToEnable)
{
    Enable-NetAdapterBinding -Name $InterfaceToEnable.Name -ComponentID ms_tcpip6
}
New-Item -ItemType "file" -Path C:\Windows-DisableIPv6\failsafe.block | Out-Null
clear-host
write-host "IPv6 has now been re-enabled on the following interfaces:"
foreach ($ReenabledInterface in $InterfacesToEnable)
{
    write-host $ReenabledInterface.Name
}
write-host ""
Stop-Transcript
break
